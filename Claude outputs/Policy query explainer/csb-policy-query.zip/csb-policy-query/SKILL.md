---
name: "csb-policy-query"
description: "Answer a question using only the Claremont School Board Policies (the policy index Google Doc and the documents it links), citing each policy used, or reply \"Insufficient Data.\" Use for any question about what Claremont school board policy says, requires, allows or prohibits."
---

# csb-policy-query

Answers Kevin's question from one source only: the Claremont School Board Policies index and the documents it links. Every answer cites the policy text it rests on. If the policies do not answer the question, the reply is exactly:

Insufficient Data.

## Source and scope

- Policy index: Google Doc `1JmygIGNaVc8ZfaQWtoIA25tRaBGw2Oh5k5ARsGlreqg`, title "Claremont School Board Policies", https://docs.google.com/document/d/1JmygIGNaVc8ZfaQWtoIA25tRaBGw2Oh5k5ARsGlreqg/edit?tab=t.0#heading=h.gjdgxs
- Structure: H1 headings are Section A (Foundation and Basic Commitments) through Section L (Education Agency Relations). Each paragraph is one entry: a linked code and title, often a date in parentheses (the index date), sometimes a note such as *also JIB*, and sometimes extra links for regulations (-R), forms (-F) or exhibits. About 350 links, almost all Google Docs or Drive files in shared drive `0AI76xqWhKvldUk9PVA`; one external link (NH Code of Conduct for NH Educators, education.nh.gov PDF).
- In scope: the index itself, every document it links, documents hyperlinked from inside those documents, and other indexed policies that a policy names in its "Related Policies" line or an "also X" note.
- Out of scope, even when relevant: statutes or rules that a policy cites only by number (RSA, Ed rules, CFR), board minutes, meeting transcripts, handbooks not linked from a policy, news, Kevin's own project analyses, memory, general knowledge, and web search. Files in the same shared drive that the index does not link (budget reports, expenditure sheets and the like) are not policies. When a policy cites a statute, the answer may say that the policy cites it, but may not state what the statute says.

## Procedure

### 1. Read the index and build a catalog

Call `mcp__Google_Drive__read_file_content` with fileId `1JmygIGNaVc8ZfaQWtoIA25tRaBGw2Oh5k5ARsGlreqg`. The result (about 50 KB) is usually saved to a tool-results file whose path the result names. Do not read it into context; parse it with this script (save it in a scripts directory of your own, for example `/home/claude/csbq/catalog.py`):

```python
import json, re, sys
src = open(sys.argv[1]).read()
try:  # persisted connector result
    d = json.loads(src); t = json.loads(d[0]['text'])['fileContent'] if isinstance(d, list) else d['fileContent']
except Exception:
    t = src
rows, sec = [], ''
for line in t.splitlines():
    if line.startswith('# Section'): sec = line[2:].strip(); continue
    for m in re.finditer(r'\[([^\]]+)\]\((https?://[^)]+)\)\s*(\*[^*]+\*)?\s*(\(\d{1,2}/\d{1,2}/\d{4}\))?', line):
        txt, url, note, date = m.groups()
        fid = re.search(r'(?:/d/|[?&]id=)([\w-]{20,})', url)
        txt = re.sub(r'^Policy\s+', '', txt.strip().strip('()'))
        rows.append(dict(section=sec, code=txt.split()[0].rstrip(':'), title=txt, date=(date or '').strip('()'),
                         note=(note or '').strip('*'), fileId=fid.group(1) if fid else '', url=url))
json.dump(rows, open(sys.argv[2], 'w'), indent=0)
print(len(rows), 'entries')
```

Run: `python3 -I catalog.py <tool-results file> catalog.json`. If the index came back inline instead of to a file, save its fileContent to a text file and pass that. Read the index fresh on every run; it changes when the board adopts or revises policies.

### 2. Find candidate policies

Use all three routes, then merge:

1. Title and code match: grep `catalog.json` titles with several synonyms for the question's subject (for a cell phone question: phone, device, electronic, communication, technology). Policy titles use formal terms, so cast wide. If the question names a code (JICD, BEDG), take it directly.
2. Section browse: when the subject maps to a section (D fiscal, G personnel, I instruction, J students, B board operations), list that section's titles and pick the relevant ones.
3. Drive full text: `mcp__Google_Drive__search_files` with `fullText contains '<term>' and '0AI76xqWhKvldUk9PVA' in ancestors`, `excludeContentSnippets: true`. Keep only results whose ID is in `catalog.json` (or that are linked from a policy you already read); drop the rest. This route misses documents often, so never rely on it alone.

Optional fast path: if the consolidator cache exists on Kevin's computer (`$HOME/mnt/Government Transparency Project/policy-consolidator/policy-cache/manifest.json` in device_bash), grep `pdftotext` output of its `pdf/*.pdf` files for the question's terms to find candidates across every active policy. Still read the live document in step 3 before citing it; the cache may be stale.

Rank candidates and read the strongest, normally 3 to 8 documents.

### 3. Read the documents

`mcp__Google_Drive__read_file_content` with each fileId (native Google Docs and Word or PDF files in Drive all return text). For each one note: code, title, the policy's own adoption, revision and review dates, its "Related Policies" line, and any hyperlinks. Follow related policies, regulations (-R) and linked documents one level further when they bear on the question. For the external NH DOE link, WebFetch is allowed because the index links it.

### 4. Decide what the policies support

- Answer only what the text states. Do not fill gaps with inference about practice, intent or law.
- Fully unsupported: the whole reply is `Insufficient Data.` with nothing added.
- Partly supported: answer the supported part with citations, then state `Insufficient Data` for the named remainder (for example, "On the consequences for staff: Insufficient Data.").
- Conflicting or overlapping policies (example: JICAB Electronic Communication/Recording Devices, 11/17/2010, and JICJ Unauthorized Communication Devices, 9/17/2025, both listed): report each with its dates and what it says. Say one supersedes the other only when a policy's text or the index says so; otherwise note that both are listed in the index.
- Dates: give the index date and, when it differs, the adoption or review date printed in the document.

### 5. Write the answer

- Lead with the direct answer, then the support. Plain, direct prose; no em dashes.
- Cite every claim at the point it is made, in this form: Policy JICJ, Unauthorized Communication Devices, Section J, index date 9/17/2025, section B "Restrictions" (link). Use the document link from the index. Short verbatim quotations of policy language are fine and preferred for rules, numbers and conditions; keep every condition attached.
- End with a "Sources" list: one line per policy used, with code, title, section, index date and link, plus the index document itself.
- Do not mention this procedure, the catalog, or search routes in the answer.

## Failure handling

- Index read fails: retry once. If it still fails, reply that the policy index could not be reached (do not answer from memory, and do not say Insufficient Data, which means the policies were read and do not answer the question).
- A candidate document returns not found or permission denied: say which policy could not be read; if the answer depended on it, the affected part is unanswered for that reason, not Insufficient Data.
- Index entries with no link or no date: use what the index shows and say the date is not given.